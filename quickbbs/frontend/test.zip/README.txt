                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2251951
Stone Terrain Tile or Pathway by melabam is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a stone tile top cap created from a picture and somewhat matching that picture for texture. The reasons for the differences from the picture are that I truncated some of the ends, reduced the element numbers and also had to resize to have a 2x2 inch layout since the picture was more rectangular. The is a top cap that can be placed on openlock bases that can be obtained free from the following website.
http://www.thingiverse.com/thing:1833963. 
The top cap can be increased in size by 25% to be a true tile size.  There is a true tile size at 1 1/4 inch 2x2 as well with openlock. The free openlock Wyloch (true tile) size base can be obtained from this link. http://www.heroshoard.com/true-tiles
You could also use mine which are already set to either base size.

# Print Settings

Printer Brand: PowerSpec
Printer: PowerSpec 3D Pro
Rafts: No
Supports: No
Resolution: 0.2
Infill: 10%

Notes: 
This is a rather large file for a tile. The reason being that I tried to to as much of the texture detail as I could. It may take a little bit to load, but it will print well.